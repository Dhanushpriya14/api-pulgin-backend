<?php
/* Template Name: API Data Template */

get_header();
?>

<div class="container">
    <h1><?php the_title(); ?></h1>
    
    <div class="api-data">
        <p>Loading data...</p>
    </div>
</div>

<?php get_footer(); ?>
